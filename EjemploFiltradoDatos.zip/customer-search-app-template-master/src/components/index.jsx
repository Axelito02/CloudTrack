import React, { useState, useEffect } from 'react';
import getCustomers from '../services/getCustomers';

export function Table({ customerData }) {
  return (
    <div className='layout-column align-items-center justify-content-start'>
      <div className='card pt-30 pb-8 mt-20'>
        <table>
          <thead>
            <tr>
              <th>Name</th>
              <th>Age</th>
              <th>Location</th>
              <th>Gender</th>
              <th>Income</th>
            </tr>
          </thead>
          <tbody>
            {customerData.map((customer, index) => (
              <tr key={index}>
                <td>{customer.name}</td>
                <td>{customer.age}</td>
                <td>{customer.location}</td>
                <td>{customer.gender}</td>
                <td>{customer.income}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}

function SearchCustomer() {
  const [initialCustomerData, setInitialCustomerData] = useState([]);
  const [filteredCustomerData, setFilteredCustomerData] = useState([]);
  const [query, setQuery] = useState('');

  useEffect(() => {
    async function fetchCustomers() {
      try {
        const customers = await getCustomers();
        setInitialCustomerData(customers);
        setFilteredCustomerData(customers);
      } catch (error) {
        console.error("Error fetching data:", error);
      }
    }

    fetchCustomers();
  }, []);

  useEffect(() => {
    const filteredCustomers = initialCustomerData.filter(customer =>
      customer.name.toLowerCase().includes(query.toLowerCase()) ||
      customer.age.toString().includes(query) ||
      customer.location.toLowerCase().includes(query.toLowerCase()) ||
      customer.income.toString().includes(query)
    );
    setFilteredCustomerData(filteredCustomers);
  }, [query, initialCustomerData]);

  return (
    <>
      <div className='layout-row align-items-center justify-content-center mt-30'>
        <input
          className='large mx-20 w-20'
          placeholder='Enter search term (Eg: Phil)'
          value={query}
          onChange={(e) => setQuery(e.target.value)}
        />
      </div>

      <Table customerData={filteredCustomerData} />
    </>
  );
}

export default SearchCustomer;
